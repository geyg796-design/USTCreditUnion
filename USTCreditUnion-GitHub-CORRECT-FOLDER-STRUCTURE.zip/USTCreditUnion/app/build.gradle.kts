plugins { id("com.android.application") }

android {
    namespace = "com.ustcreditunion.simulator"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ustcreditunion.simulator"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity:1.10.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.12.1")
}
